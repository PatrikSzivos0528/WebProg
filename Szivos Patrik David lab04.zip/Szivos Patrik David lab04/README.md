# Fundamentals of Web Development, 2nd Edition
### Chapter 4 [Introduction to CSS], Lab

What You Will Learn
* How to use CSS to style HTML documents
* How to use CSS selectors
* The CSS box model