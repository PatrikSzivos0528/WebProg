# Fundamentals of Web Development, 2nd Edition
### Chapter 3 [Introduction to HTML], Lab

What You Will Learn
* How to create HTML documents
* Basic HTML structure
* How to creating hyperlinks
* How to add images to a web page
* HTML5 semantic tags