# Fundamentals of Web Development, 2nd Edition
### Chapter 5 [HTML Tables and Forms], Lab

What You Will Learn
* How to create HTML tables
* How to style tables
* How to create HTML forms